People and credit are listed in no particular order.


# Blahness98
* [Classes/Archetypes](https://www.fantasygrounds.com/forums/showthread.php?50404-Class-and-Archetype-Module)

# JoshyNeurotic AKA Joshy Neurotic (JoshyNeurotic AKA Joshy Neurotic#4820)
Provided the database of archetypes