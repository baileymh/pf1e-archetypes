# Changelog

## 0.1.0

### Changelog

- Create initial Release
- Added source files: xmls, csvs, and dbs
- Added packages for archetypes (merged and individual), class abilities, and archetype features
- Added templates for archetypes and abilities
- Added LICENSE for GNU General Public License
- Added OGL.txt for Open Game License Version 1.0a
- Added Legal.text for Paizo Inc.
- Added README.md
- Added changelog.md
- Added module.json
